# Utopy — Protótipo inicial

Protótipo estático de interface para a plataforma de participação cidadã e transparência pública Utopy.

## Como executar no VS Code

1. Extraia a pasta `utopy-prototipo`.
2. Abra essa pasta no Visual Studio Code.
3. Abra o arquivo `index.html` no navegador.

**Recomendado:** instale a extensão **Live Server** no VS Code. Depois, clique com o botão direito em `index.html` e escolha **Open with Live Server**. Assim, as alterações serão atualizadas automaticamente no navegador.

Não é necessário instalar Node.js ou dependências para executar esta versão.

## Estrutura

```text
utopy-prototipo/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── README.md
```

## O que já está implementado

- Identidade visual inicial da Utopy.
- Layout responsivo para desktop, tablet e celular.
- Navegação com menu adaptado para telas pequenas.
- Seções de comunidade, obras públicas e transparência.
- Filtros de publicações por categoria.
- Botões de apoio interativos.
- Modais demonstrativos de login, cadastro e nova discussão.
- Estados de foco visíveis, link para pular ao conteúdo e suporte a `prefers-reduced-motion`.

## Importante

Esta é uma demonstração frontend. Os indicadores, publicações, obras, documentos e valores são fictícios. Login, cadastro, publicação e consulta de dados ainda não estão conectados a banco de dados ou API. Os botões demonstram a experiência visual e não salvam informações.

Antes de publicar o sistema, será necessário implementar autenticação, autorização, validação no servidor, moderação, proteção de dados e integração com fontes oficiais verificáveis.

## Personalização

As cores principais estão no início de `css/styles.css`, dentro de `:root`. Altere as variáveis `--navy`, `--green`, `--mint`, `--background` e `--accent` para ajustar a identidade visual.

O conteúdo e a estrutura das seções ficam em `index.html`. As interações ficam em `js/app.js`.
