// Utopy — interações demonstrativas do protótipo.
// As ações ainda não persistem dados nem se comunicam com um backend.
const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("is-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Fechar menu" : "Abrir menu");
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Abrir menu");
  });
});

// Filtro por categoria.
const filterButtons = document.querySelectorAll("[data-filter]");
const posts = document.querySelectorAll(".post");
const emptyState = document.querySelector("#empty-state");

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const category = button.dataset.filter;
    let visibleCount = 0;

    filterButtons.forEach((item) => {
      const active = item === button;
      item.classList.toggle("is-active", active);
      item.setAttribute("aria-pressed", String(active));
    });

    posts.forEach((post) => {
      const visible = category === "Todas" || post.dataset.category === category;
      post.hidden = !visible;
      if (visible) visibleCount += 1;
    });

    emptyState.hidden = visibleCount !== 0;
  });
});

// Apoios locais, apenas para demonstrar a interação.
document.querySelectorAll(".support-button").forEach((button) => {
  button.addEventListener("click", () => {
    const active = button.getAttribute("aria-pressed") !== "true";
    const count = button.querySelector("span");
    const current = Number(count.textContent);
    button.setAttribute("aria-pressed", String(active));
    count.textContent = String(current + (active ? 1 : -1));
    button.firstChild.textContent = active ? "♥ " : "♡ ";
    showToast(active ? "Apoio registrado nesta demonstração." : "Apoio retirado.");
  });
});

// Modal demonstrativo: pronto para ser conectado a formulários reais depois.
const modal = document.querySelector("#app-modal");
const modalTitle = document.querySelector("#modal-title");
const modalDescription = document.querySelector("#modal-description");
const modalContent = document.querySelector("#modal-content");
const modalConfirm = document.querySelector("#modal-confirm");
let previousFocus = null;

const modalTemplates = {
  login: {
    title: "Entrar na Utopy",
    description: "A autenticação será implementada na próxima etapa.",
    content: '<label for="login-email">E-mail</label><input id="login-email" type="email" autocomplete="email" placeholder="seu@email.com"><label for="login-password">Senha</label><input id="login-password" type="password" autocomplete="current-password" placeholder="Sua senha">'
  },
  register: {
    title: "Criar minha conta",
    description: "Em breve, você poderá participar das discussões e propostas da sua cidade.",
    content: '<label for="register-name">Nome</label><input id="register-name" autocomplete="name" placeholder="Seu nome"><label for="register-email">E-mail</label><input id="register-email" type="email" autocomplete="email" placeholder="seu@email.com">'
  },
  post: {
    title: "Nova discussão",
    description: "Experimente a estrutura de publicação. O envio real será habilitado após a integração com a API.",
    content: '<form id="demo-post-form"><label for="post-title">Título</label><input id="post-title" maxlength="100" required placeholder="Qual é a sua ideia?"><label for="post-category">Categoria</label><select id="post-category"><option>Infraestrutura</option><option>Saúde</option><option>Educação</option><option>Meio ambiente</option></select><label for="post-body">Descrição</label><textarea id="post-body" maxlength="1000" required placeholder="Conte mais sobre o assunto"></textarea></form>'
  },
  info: {
    title: "Informações demonstrativas",
    description: "Esta seção será conectada aos dados e documentos oficiais quando a plataforma estiver integrada.",
    content: '<p class="demo-warning">Os dados exibidos nesta versão são fictícios. Não devem ser utilizados como informações municipais reais.</p>'
  }
};

function openModal(type) {
  const template = modalTemplates[type];
  if (!template) return;
  previousFocus = document.activeElement;
  modalTitle.textContent = template.title;
  modalDescription.textContent = template.description;
  modalContent.innerHTML = template.content;
  modalConfirm.textContent = type === "post" ? "Publicar demonstração" : "Entendi";
  modal.hidden = false;
  document.body.style.overflow = "hidden";
  const firstInput = modal.querySelector("input, textarea, select");
  (firstInput || modal.querySelector("[data-close]")).focus();
}

function closeModal() {
  modal.hidden = true;
  document.body.style.overflow = "";
  if (previousFocus) previousFocus.focus();
}

document.querySelectorAll("[data-modal]").forEach((button) => {
  button.addEventListener("click", () => openModal(button.dataset.modal));
});
document.querySelectorAll("[data-close]").forEach((button) => {
  button.addEventListener("click", closeModal);
});
modal.addEventListener("click", (event) => {
  if (event.target === modal) closeModal();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !modal.hidden) closeModal();
  if (event.key === "Tab" && !modal.hidden) {
    const focusable = [...modal.querySelectorAll('button, input, textarea, select, [href], [tabindex]:not([tabindex="-1"])')].filter((el) => !el.disabled);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault(); last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault(); first.focus();
    }
  }
});

modalConfirm.addEventListener("click", () => {
  const form = document.querySelector("#demo-post-form");
  if (form) {
    if (!form.reportValidity()) return;
    showToast("Publicação de demonstração validada. Ainda não foi salva.");
  }
  closeModal();
});

let toastTimer;
function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 2800);
}
